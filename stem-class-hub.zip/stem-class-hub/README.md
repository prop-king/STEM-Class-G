# 11–12G STEM Class Hub

A responsive, shared-database class portal for the 11–12G STEM Class at the National School of Excellence. The supplied school logo is included as `public/school-logo.jpeg` and used without redesigning it.

## Implemented in this starter

- Responsive public home, About Us, seven subject areas, Teachers section, Students Hub entry points, timetable, and class gallery landing section.
- Express server with persistent SQLite database and server-side sessions stored in SQLite.
- Hashed passwords, role checks on protected routes, login rate limiting, HTTP security headers, session regeneration at login, and an eight-hour session lifetime.
- One-time first-admin bootstrap flow using a deployment environment token; no built-in default account or password.
- Administrator account creation/suspension, content management, timetable management, audit log viewing, and a password-confirmed administrator handover flow.
- Shared announcements, resources, assignments, events, briefings, gallery metadata, and page-content records through the database-backed content API.
- Restricted resource attachment upload/download (8 MB maximum; allowed extensions; random server filenames), assignment text submissions, teacher/admin feedback and marks.
- Basic deployment health endpoint and printable timetable.

## Important scope notes

This is a usable development foundation, not a claim that every item in the large master prompt is complete or production-certified. The following need further implementation/configuration before school-wide production use: email verification and password reset, MFA, secure invitation-code workflows, robust photo/image optimisation and gallery album/comment moderation, real-time messaging and notifications, email delivery, granular field-level student privacy rules, CSV import/export, backups and restore automation, malware scanning, full automated test coverage, formal security review, and deployment-specific TLS/secret management. The public gallery is a landing section; uploaded gallery records currently use the general content workflow. Do not enter real sensitive student data until the school's responsible staff have reviewed privacy and access controls.

The timetable begins empty on purpose. Teacher identities and student data are not invented. The seven subject names are preconfigured.

## Requirements

- Node.js 20 or newer
- npm

## Run locally

1. Extract the project folder.
2. Open a terminal in that folder.
3. Install packages:

   ```bash
   npm install
   ```

4. Set environment variables. Copy `.env.example` to `.env` and set `SESSION_SECRET` to a long random value. Set `BOOTSTRAP_TOKEN` to a random one-time token of at least 24 characters. Environment variables are not loaded automatically from `.env`; either export them in your terminal or install/use a dotenv loader. For a quick PowerShell session:

   ```powershell
   $env:SESSION_SECRET = "replace-with-a-long-random-secret"
   $env:BOOTSTRAP_TOKEN = "replace-with-a-random-token-at-least-24-characters"
   npm start
   ```

   On macOS/Linux:

   ```bash
   export SESSION_SECRET='replace-with-a-long-random-secret'
   export BOOTSTRAP_TOKEN='replace-with-a-random-token-at-least-24-characters'
   npm start
   ```

5. Open `http://localhost:3000`.
6. Open **Sign in** and expand **First-time administrator setup**. Enter the exact bootstrap token, administrator name, username and a unique password of at least 12 characters.
7. After the first admin is created, bootstrap is disabled in the running process. Remove `BOOTSTRAP_TOKEN` from the server environment and restart the app. Keep `SESSION_SECRET` stable between restarts.
8. Sign in as administrator and create individual student and teacher accounts. Enter the actual timetable when confirmed.

## Persistent data

- SQLite database: `data/stem-hub.sqlite`
- Session store: `data/sessions.sqlite`
- Uploaded files: `public/uploads/`

Back up the database and uploads together using a consistent backup procedure while the app is stopped or using SQLite's online backup capabilities. A backup status indicator is not implemented, so do not assume backups are running automatically.

## Production deployment checklist

- Use HTTPS and set `NODE_ENV=production`.
- Configure strong random `SESSION_SECRET` in the host's secret manager.
- Do not expose `BOOTSTRAP_TOKEN` after initial setup; remove it after the first admin is created.
- Use persistent disk storage for SQLite and uploaded files, or migrate to managed PostgreSQL/object storage for multiple server instances.
- Do not deploy this SQLite version to ephemeral storage or horizontally scale it without redesigning the database/session/file-storage layer.
- Set restrictive file permissions and configure backup/restore, monitoring, and retention.
- Complete the remaining safety/privacy features and independent security testing before importing personal student information.

## Main files

```text
stem-class-hub/
├── server.js              # API, authentication, database, permissions
├── package.json
├── .env.example
├── README.md
├── data/                  # Created at runtime; SQLite database and sessions
└── public/
    ├── index.html         # Main page and dashboard sections
    ├── styles.css         # Responsive design system
    ├── app.js             # Frontend interactions and API calls
    ├── school-logo.jpeg   # Supplied official logo
    └── uploads/           # Uploaded attachments
```
