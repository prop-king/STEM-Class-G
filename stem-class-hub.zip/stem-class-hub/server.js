const express = require('express');
const session = require('express-session');
const SQLiteStoreFactory = require('connect-sqlite3')(session);
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const ROOT = __dirname;
const DATA_DIR = path.join(ROOT, 'data');
const UPLOAD_DIR = path.join(ROOT, 'public', 'uploads');
fs.mkdirSync(DATA_DIR, { recursive: true }); fs.mkdirSync(UPLOAD_DIR, { recursive: true });
if (process.env.NODE_ENV === 'production' && !process.env.SESSION_SECRET) throw new Error('SESSION_SECRET is required in production.');
const db = new Database(path.join(DATA_DIR, 'stem-hub.sqlite'));
db.pragma('journal_mode = WAL'); db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id TEXT PRIMARY KEY, username TEXT NOT NULL UNIQUE, full_name TEXT NOT NULL,
 password_hash TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN ('student','teacher','moderator','admin')),
 subject TEXT, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS content (
 id TEXT PRIMARY KEY, type TEXT NOT NULL, title TEXT NOT NULL, body TEXT DEFAULT '', subject TEXT DEFAULT '',
 due_at TEXT, status TEXT NOT NULL DEFAULT 'published', author_id TEXT, file_name TEXT,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(author_id) REFERENCES users(id)
);
CREATE INDEX IF NOT EXISTS content_type_created ON content(type, created_at DESC);
CREATE TABLE IF NOT EXISTS submissions (
 id TEXT PRIMARY KEY, assignment_id TEXT NOT NULL, student_id TEXT NOT NULL, response TEXT DEFAULT '', file_name TEXT,
 status TEXT NOT NULL DEFAULT 'submitted', mark REAL, feedback TEXT DEFAULT '', submitted_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(assignment_id, student_id), FOREIGN KEY(assignment_id) REFERENCES content(id), FOREIGN KEY(student_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS timetable (
 id TEXT PRIMARY KEY, day TEXT NOT NULL, start_time TEXT NOT NULL, end_time TEXT NOT NULL,
 subject TEXT NOT NULL, teacher TEXT DEFAULT '', venue TEXT DEFAULT '', notes TEXT DEFAULT '', updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS audit_logs (
 id TEXT PRIMARY KEY, actor_id TEXT, action TEXT NOT NULL, target_type TEXT, target_id TEXT, detail TEXT DEFAULT '',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(actor_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
`);
const subjects = ['Chemistry','Biology','Mathematics','Language and Literature','Engineering','Physics','Technology'];
const uid = () => crypto.randomUUID();
function audit(actor, action, targetType='', targetId='', detail='') {
  db.prepare('INSERT INTO audit_logs (id, actor_id, action, target_type, target_id, detail) VALUES (?,?,?,?,?,?)')
    .run(uid(), actor?.id || null, action, targetType, targetId, String(detail).slice(0,500));
}
function safeUser(u) { if (!u) return null; return {id:u.id, username:u.username, fullName:u.full_name, role:u.role, subject:u.subject, active:!!u.active}; }
function requireAuth(req,res,next) { if (!req.session.user) return res.status(401).json({error:'Please sign in to continue.'}); const u=db.prepare('SELECT * FROM users WHERE id=? AND active=1').get(req.session.user.id); if(!u){req.session.destroy(()=>{});return res.status(401).json({error:'Your account is inactive. Contact the administrator.'});} req.user=u; next(); }
function allow(...roles) { return (req,res,next)=>{ if(!req.user || !roles.includes(req.user.role)) return res.status(403).json({error:'You do not have permission to perform this action.'}); next(); }; }
function canManageContent(user, item) { return user.role==='admin' || (['teacher','moderator'].includes(user.role) && item.author_id===user.id); }
const upload = multer({storage:multer.diskStorage({destination:UPLOAD_DIR,filename:(req,file,cb)=>cb(null,crypto.randomUUID()+path.extname(file.originalname).toLowerCase())}),limits:{fileSize:8*1024*1024},fileFilter:(req,file,cb)=>{const ext=path.extname(file.originalname).toLowerCase(); const allowed=['.pdf','.docx','.pptx','.xlsx','.txt','.jpg','.jpeg','.png','.webp']; if(!allowed.includes(ext)) return cb(new Error('File type not allowed. Upload PDF, Office documents, TXT, JPG, PNG, or WEBP.')); cb(null,true);}});
app.disable('x-powered-by');
app.use(helmet({contentSecurityPolicy:{directives:{defaultSrc:["'self'"],scriptSrc:["'self'"],styleSrc:["'self'","'unsafe-inline'"],imgSrc:["'self'","data:"],connectSrc:["'self'"],objectSrc:["'none'"],frameAncestors:["'none'"]}}}));
app.use(express.json({limit:'1mb'})); app.use(express.urlencoded({extended:false}));
app.use(session({name:'stemhub.sid',secret:process.env.SESSION_SECRET||'development-only-change-this-secret-before-deployment',resave:false,saveUninitialized:false,store:new SQLiteStoreFactory({db:'sessions.sqlite',dir:DATA_DIR}),cookie:{httpOnly:true,sameSite:'lax',secure:process.env.NODE_ENV==='production',maxAge:1000*60*60*8}}));
app.use(express.static(path.join(ROOT,'public')));
const loginLimiter=rateLimit({windowMs:15*60*1000,limit:10,standardHeaders:true,legacyHeaders:false,message:{error:'Too many login attempts. Please wait and try again.'}});
app.get('/api/health',(req,res)=>res.json({ok:true,service:'11–12G STEM Class Hub',database:'connected'}));
app.get('/api/bootstrap-status',(req,res)=>res.json({available:db.prepare("SELECT COUNT(*) AS n FROM users WHERE role='admin'").get().n===0 && !!process.env.BOOTSTRAP_TOKEN}));
app.get('/api/me',(req,res)=>res.json({user:safeUser(req.session.user)}));
app.post('/api/login',loginLimiter,(req,res)=>{
 const username=String(req.body.username||'').trim().toLowerCase(); const password=String(req.body.password||'');
 if(!username||!password) return res.status(400).json({error:'Enter your username and password.'});
 const user=db.prepare('SELECT * FROM users WHERE username=?').get(username);
 if(!user||!user.active||!bcrypt.compareSync(password,user.password_hash)){audit(user||null,'login_failed','user',user?.id||'',`username=${username}`);return res.status(401).json({error:'Username or password is incorrect.'});}
 req.session.regenerate(err=>{if(err)return res.status(500).json({error:'Could not start a secure session.'});req.session.user=safeUser(user);audit(user,'login','user',user.id);res.json({user:safeUser(user)});});
});
app.post('/api/logout',requireAuth,(req,res)=>{audit(req.user,'logout','user',req.user.id);req.session.destroy(()=>res.json({ok:true}));});
app.post('/api/bootstrap-admin',loginLimiter,(req,res)=>{
 const token=String(req.body.token||''); const expected=process.env.BOOTSTRAP_TOKEN;
 if(!expected || token.length<24 || token.length!==expected.length || !crypto.timingSafeEqual(Buffer.from(token),Buffer.from(expected))) return res.status(403).json({error:'Administrator setup token is invalid or setup is disabled.'});
 if(db.prepare("SELECT COUNT(*) AS n FROM users WHERE role='admin'").get().n>0){delete process.env.BOOTSTRAP_TOKEN;return res.status(409).json({error:'An administrator already exists. Bootstrap is disabled.'});}
 const username=String(req.body.username||'').trim().toLowerCase(), fullName=String(req.body.fullName||'').trim(), password=String(req.body.password||'');
 if(!/^[a-z0-9._-]{3,32}$/.test(username)||fullName.length<2||password.length<12) return res.status(400).json({error:'Use a 3–32 character username, full name, and password of at least 12 characters.'});
 const id=uid(); db.prepare('INSERT INTO users (id,username,full_name,password_hash,role) VALUES (?,?,?,?,?)').run(id,username,fullName,bcrypt.hashSync(password,12),'admin');
 delete process.env.BOOTSTRAP_TOKEN; audit({id},'bootstrap_admin_created','user',id); res.status(201).json({ok:true,message:'Administrator created. The bootstrap token is now disabled. Sign in to continue.'});
});
app.get('/api/overview',(req,res)=>{
 const types=['announcement','resource','assignment','event','briefing','gallery']; const counts={};
 for(const type of types) counts[type]=db.prepare("SELECT COUNT(*) n FROM content WHERE type=? AND status='published'").get(type).n;
 const upcoming=db.prepare("SELECT id,title,body,subject,due_at,type,created_at FROM content WHERE type IN ('assignment','event') AND status='published' ORDER BY COALESCE(due_at,created_at) ASC LIMIT 5").all();
 const announcements=db.prepare("SELECT id,title,body,subject,created_at FROM content WHERE type='announcement' AND status='published' ORDER BY created_at DESC LIMIT 5").all();
 res.json({counts,upcoming,announcements,subjects});
});
app.get('/api/content',requireAuth,(req,res)=>{
 const type=String(req.query.type||''); const allowed=['announcement','resource','assignment','event','briefing','gallery','page'];
 if(!allowed.includes(type)) return res.status(400).json({error:'Choose a valid content category.'});
 const items=db.prepare('SELECT c.id,c.type,c.title,c.body,c.subject,c.due_at,c.status,c.author_id,c.file_name,c.created_at,c.updated_at,u.full_name AS author_name FROM content c LEFT JOIN users u ON u.id=c.author_id WHERE c.type=? AND (c.status=\'published\' OR c.author_id=? OR ?) ORDER BY c.created_at DESC LIMIT 200').all(type,req.user.id,req.user.role==='admin'?1:0);
 res.json({items});
});
app.post('/api/content',requireAuth,allow('admin','teacher','moderator'),upload.single('file'),(req,res)=>{
 const type=String(req.body.type||''); const allowed=['announcement','resource','assignment','event','briefing','gallery','page'];
 const title=String(req.body.title||'').trim(), body=String(req.body.body||'').trim(), subject=String(req.body.subject||'').trim(), status=String(req.body.status||'published');
 if(!allowed.includes(type)||title.length<2||title.length>180) {if(req.file)fs.unlinkSync(req.file.path);return res.status(400).json({error:'Choose a valid category and enter a title (2–180 characters).'});}
 if(!['draft','published','archived'].includes(status)){if(req.file)fs.unlinkSync(req.file.path);return res.status(400).json({error:'Invalid publication status.'});}
 if(req.user.role!=='admin' && ['briefing','page'].includes(type)) {if(req.file)fs.unlinkSync(req.file.path);return res.status(403).json({error:'Only the administrator can publish this type of content.'});}
 const id=uid(), fileName=req.file?path.basename(req.file.filename):null;
 db.prepare('INSERT INTO content (id,type,title,body,subject,due_at,status,author_id,file_name) VALUES (?,?,?,?,?,?,?,?,?)').run(id,type,title,body,subject,String(req.body.dueAt||'').slice(0,40)||null,status,req.user.id,fileName);
 audit(req.user,'content_created',type,id,title); res.status(201).json({item:db.prepare('SELECT * FROM content WHERE id=?').get(id)});
});
app.patch('/api/content/:id',requireAuth,allow('admin','teacher','moderator'),(req,res)=>{
 const old=db.prepare('SELECT * FROM content WHERE id=?').get(req.params.id); if(!old)return res.status(404).json({error:'Content not found.'}); if(!canManageContent(req.user,old))return res.status(403).json({error:'You can only edit your own content.'});
 const title=String(req.body.title??old.title).trim(); if(title.length<2||title.length>180)return res.status(400).json({error:'Title must be 2–180 characters.'});
 const body=String(req.body.body??old.body).trim(), subject=String(req.body.subject??old.subject).trim(), status=String(req.body.status??old.status); if(!['draft','published','archived'].includes(status))return res.status(400).json({error:'Invalid status.'});
 db.prepare('UPDATE content SET title=?,body=?,subject=?,due_at=?,status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(title,body,subject,String(req.body.dueAt??old.due_at??'')||null,status,old.id); audit(req.user,'content_updated',old.type,old.id,title);res.json({item:db.prepare('SELECT * FROM content WHERE id=?').get(old.id)});
});
app.delete('/api/content/:id',requireAuth,allow('admin','teacher','moderator'),(req,res)=>{const item=db.prepare('SELECT * FROM content WHERE id=?').get(req.params.id);if(!item)return res.status(404).json({error:'Content not found.'});if(!canManageContent(req.user,item))return res.status(403).json({error:'You can only delete your own content.'});if(item.file_name){const p=path.join(UPLOAD_DIR,path.basename(item.file_name));if(fs.existsSync(p))fs.unlinkSync(p);}db.prepare('DELETE FROM content WHERE id=?').run(item.id);audit(req.user,'content_deleted',item.type,item.id,item.title);res.json({ok:true});});
app.get('/api/timetable', (req,res)=>res.json({items:db.prepare('SELECT * FROM timetable ORDER BY CASE day WHEN \'Monday\' THEN 1 WHEN \'Tuesday\' THEN 2 WHEN \'Wednesday\' THEN 3 WHEN \'Thursday\' THEN 4 WHEN \'Friday\' THEN 5 ELSE 6 END,start_time').all()}));
app.post('/api/timetable',requireAuth,allow('admin'),(req,res)=>{const {day,startTime,endTime,subject,teacher='',venue='',notes=''}=req.body;if(!['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'].includes(day)||!startTime||!endTime||startTime>=endTime||!subjects.includes(subject))return res.status(400).json({error:'Check the day, subject, and time range.'});const id=uid();db.prepare('INSERT INTO timetable (id,day,start_time,end_time,subject,teacher,venue,notes) VALUES (?,?,?,?,?,?,?,?)').run(id,day,startTime,endTime,subject,String(teacher).slice(0,100),String(venue).slice(0,100),String(notes).slice(0,500));audit(req.user,'timetable_created','timetable',id,`${day} ${startTime}-${endTime}`);res.status(201).json({item:db.prepare('SELECT * FROM timetable WHERE id=?').get(id)});});
app.delete('/api/timetable/:id',requireAuth,allow('admin'),(req,res)=>{db.prepare('DELETE FROM timetable WHERE id=?').run(req.params.id);audit(req.user,'timetable_deleted','timetable',req.params.id);res.json({ok:true});});
app.get('/api/users',requireAuth,allow('admin'),(req,res)=>res.json({items:db.prepare('SELECT id,username,full_name,role,subject,active,created_at FROM users ORDER BY role,full_name').all()}));
app.post('/api/users',requireAuth,allow('admin'),(req,res)=>{const username=String(req.body.username||'').trim().toLowerCase(),fullName=String(req.body.fullName||'').trim(),password=String(req.body.password||''),role=String(req.body.role||''),subject=String(req.body.subject||'');if(!/^[a-z0-9._-]{3,32}$/.test(username)||fullName.length<2||password.length<12||!['student','teacher','moderator'].includes(role))return res.status(400).json({error:'Check username, full name, password (12+ characters), and role.'});try{const id=uid();db.prepare('INSERT INTO users (id,username,full_name,password_hash,role,subject) VALUES (?,?,?,?,?,?)').run(id,username,fullName,bcrypt.hashSync(password,12),role,subject||null);audit(req.user,'user_created','user',id,`${username}:${role}`);res.status(201).json({ok:true});}catch(e){if(String(e.code).includes('CONSTRAINT'))return res.status(409).json({error:'That username is already in use.'});throw e;}});
app.patch('/api/users/:id',requireAuth,allow('admin'),(req,res)=>{const target=db.prepare('SELECT * FROM users WHERE id=?').get(req.params.id);if(!target)return res.status(404).json({error:'Account not found.'});if(target.role==='admin'&&target.id===req.user.id&&req.body.active===false)return res.status(400).json({error:'You cannot deactivate your own administrator account.'});if(target.role==='admin'&&req.body.role&&req.body.role!=='admin')return res.status(400).json({error:'Use the secure handover process to change administrator privileges.'});const active=req.body.active===undefined?target.active:(req.body.active?1:0);db.prepare('UPDATE users SET active=? WHERE id=?').run(active,target.id);audit(req.user,'user_status_changed','user',target.id,`active=${active}`);res.json({ok:true});});
app.get('/api/admin/audit',requireAuth,allow('admin'),(req,res)=>res.json({items:db.prepare('SELECT a.*,u.username,u.full_name FROM audit_logs a LEFT JOIN users u ON u.id=a.actor_id ORDER BY a.created_at DESC LIMIT 100').all()}));
app.post('/api/submissions',requireAuth,allow('student'),(req,res)=>{const assignment=db.prepare("SELECT * FROM content WHERE id=? AND type='assignment' AND status='published'").get(req.body.assignmentId);if(!assignment)return res.status(404).json({error:'Assignment not found.'});const response=String(req.body.response||'').trim();if(!response)return res.status(400).json({error:'Enter your response before submitting.'});const id=uid();try{db.prepare('INSERT INTO submissions (id,assignment_id,student_id,response) VALUES (?,?,?,?)').run(id,assignment.id,req.user.id,response);audit(req.user,'assignment_submitted','assignment',assignment.id);res.status(201).json({ok:true,message:'Your submission has been saved.'});}catch(e){if(String(e.code).includes('CONSTRAINT'))return res.status(409).json({error:'You have already submitted this assignment. Contact your teacher if a resubmission is needed.'});throw e;}});
app.get('/api/submissions',requireAuth,(req,res)=>{let items;if(req.user.role==='student')items=db.prepare('SELECT s.*,c.title AS assignment_title,c.subject FROM submissions s JOIN content c ON c.id=s.assignment_id WHERE s.student_id=? ORDER BY s.submitted_at DESC').all(req.user.id);else if(req.user.role==='teacher'||req.user.role==='admin')items=db.prepare('SELECT s.*,c.title AS assignment_title,c.subject,u.full_name AS student_name FROM submissions s JOIN content c ON c.id=s.assignment_id JOIN users u ON u.id=s.student_id WHERE ?=1 OR c.author_id=? ORDER BY s.submitted_at DESC LIMIT 300').all(req.user.role==='admin'?1:0,req.user.id);else return res.status(403).json({error:'Not permitted.'});res.json({items});});
app.patch('/api/submissions/:id',requireAuth,allow('teacher','admin'),(req,res)=>{const s=db.prepare('SELECT s.*,c.author_id FROM submissions s JOIN content c ON c.id=s.assignment_id WHERE s.id=?').get(req.params.id);if(!s)return res.status(404).json({error:'Submission not found.'});if(req.user.role!=='admin'&&s.author_id!==req.user.id)return res.status(403).json({error:'You can only review submissions for your assignments.'});const mark=req.body.mark===null||req.body.mark===''?null:Number(req.body.mark);if(mark!==null&&(!Number.isFinite(mark)||mark<0||mark>1000))return res.status(400).json({error:'Enter a valid mark.'});db.prepare('UPDATE submissions SET mark=?,feedback=?,status=\'returned\' WHERE id=?').run(mark,String(req.body.feedback||'').slice(0,4000),s.id);audit(req.user,'submission_reviewed','submission',s.id);res.json({ok:true});});
app.get('/api/file/:name',requireAuth,(req,res)=>{const name=path.basename(req.params.name);const row=db.prepare('SELECT * FROM content WHERE file_name=?').get(name);if(!row)return res.status(404).json({error:'File not found.'});if(row.status!=='published'&&!canManageContent(req.user,row))return res.status(403).json({error:'You do not have permission to download this file.'});res.download(path.join(UPLOAD_DIR,name));});
app.post('/api/succession',requireAuth,allow('admin'),(req,res)=>{const {successorId,password,confirmation}=req.body;if(!bcrypt.compareSync(String(password||''),req.user.password_hash))return res.status(401).json({error:'Re-enter your administrator password to continue.'});if(confirmation!=='TRANSFER ADMIN CONTROL')return res.status(400).json({error:'Type TRANSFER ADMIN CONTROL to confirm.'});const next=db.prepare("SELECT * FROM users WHERE id=? AND active=1 AND role IN ('teacher','moderator')").get(successorId);if(!next)return res.status(400).json({error:'Choose an active, eligible teacher or moderator account.'});const transfer=db.transaction(()=>{db.prepare("UPDATE users SET role='teacher' WHERE id=?").run(req.user.id);db.prepare("UPDATE users SET role='admin' WHERE id=?").run(next.id);audit(req.user,'admin_succession_out','user',req.user.id,`successor=${next.id}`);audit({id:next.id},'admin_succession_in','user',next.id,`previous=${req.user.id}`);});transfer();req.session.destroy(()=>res.json({ok:true,message:`Administrator control transferred to ${next.full_name}. Please sign in again.`}));});
app.use((err,req,res,next)=>{console.error(err.message);if(err instanceof multer.MulterError)return res.status(400).json({error:err.code==='LIMIT_FILE_SIZE'?'File is too large. Maximum size is 8 MB.':'Upload failed.'});if(err.message?.startsWith('File type not allowed'))return res.status(400).json({error:err.message});res.status(500).json({error:'Something went wrong. Please try again.'});});
app.get('*',(req,res)=>res.sendFile(path.join(ROOT,'public','index.html')));
app.listen(PORT,()=>console.log(`11–12G STEM Class Hub running at http://localhost:${PORT}`));
