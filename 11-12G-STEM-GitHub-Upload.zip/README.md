# 11–12G STEM Class Hub

A responsive static website starter for the 11–12G STEM Class at the National School of Excellence, Papua New Guinea.

## Files included

```text
11-12G-STEM-GitHub/
├── index.html
├── style.css
├── script.js
├── README.md
└── assets/
    └── school-logo.jpeg
```

## Preview on your computer

1. Extract the ZIP file.
2. Open `index.html` in a web browser.

Optional local server (run inside the extracted folder):

```bash
python -m http.server 8000
```

Then open `http://localhost:8000`.

## Upload to GitHub and publish

1. Create a new repository on GitHub, such as `11-12g-stem-class-hub`.
2. Extract this ZIP file.
3. Upload the **contents** of the extracted folder into the repository root. Keep `index.html`, `style.css`, `script.js`, and `README.md` together, and upload the `assets` folder too.
4. Commit the files to the `main` branch.
5. Go to **Settings → Pages** in the repository.
6. Under **Build and deployment**, select **Deploy from a branch**.
7. Choose branch `main` and folder `/ (root)`, then click **Save**.
8. Wait for the GitHub Pages URL to appear on that page.

## Customise

- `index.html`: text, sections, timetable placeholders, and page structure.
- `style.css`: colours, layout, fonts, and mobile responsiveness.
- `script.js`: mobile navigation and small interactive behaviours.
- `assets/school-logo.jpeg`: supplied school logo used by the site.

The timetable is explicitly a sample layout, not the official timetable. Replace placeholder notices and links with approved class information before sharing the site.

## Important limitation

This is a **static GitHub Pages website**. It does not include a server or shared database, secure user accounts, private file storage, live messaging, assignment submissions, grade management, or a secure admin dashboard. Do not publish private student information, grades, contact details, messages, or student photographs without appropriate school approval. Those features require a properly secured backend and server-side permission checks.

## Technology

HTML5, CSS3, and vanilla JavaScript. No package installation or build step is required.
